import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Agenda Semanal',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Agenda Semanal'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  // Mapa com os dados da semana
  final Map<String, List<Map<String, String>>> agendaPorDia = {
    'Segunda-feira': [
      {'hora': '07:00', 'tarefa': 'Ir pra escola'},
      {'hora': '12:00', 'tarefa': 'Almoçar'},
      {'hora': '14:00', 'tarefa': 'Fazer dever de casa'},
      {'hora': '18:00', 'tarefa': 'Jogar futebol'},
    ],
    'Terça-feira': [
      {'hora': '07:00', 'tarefa': 'Ir pra escola'},
      {'hora': '13:00', 'tarefa': 'Curso de inglês'},
      {'hora': '16:00', 'tarefa': 'Estudar matemática'},
    ],
    'Quarta-feira': [
      {'hora': '07:00', 'tarefa': 'Ir pra escola'},
      {'hora': '15:00', 'tarefa': 'Aula de natação'},
      {'hora': '17:30', 'tarefa': 'Ler um livro'},
    ],
    'Quinta-feira': [
      {'hora': '07:00', 'tarefa': 'Ir pra escola'},
      {'hora': '14:00', 'tarefa': 'Revisar prova'},
      {'hora': '19:00', 'tarefa': 'Assistir filme'},
    ],
    'Sexta-feira': [
      {'hora': '07:00', 'tarefa': 'Ir pra escola'},
      {'hora': '12:30', 'tarefa': 'Almoçar com amigos'},
      {'hora': '15:00', 'tarefa': 'Jogar videogame'},
      {'hora': '20:00', 'tarefa': 'Sair com a família'},
    ],
  };

  void _abrirAgendaDoDia(String dia) {
    final tarefas = agendaPorDia[dia] ?? [];

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AgendaDiaPage(dia: dia, tarefas: tarefas),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final diasSemana = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira'];
    final diasAbreviados = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex'];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(5, (index) {
              return ElevatedButton(
                onPressed: () => _abrirAgendaDoDia(diasSemana[index]),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 7),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  textStyle: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                child: Text(diasAbreviados[index]),
              );
            }),
          ),
        ),
      ),
    );
  }
}

class AgendaDiaPage extends StatelessWidget {
  final String dia;
  final List<Map<String, String>> tarefas;

  const AgendaDiaPage({
    Key? key,
    required this.dia,
    required this.tarefas,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agenda de $dia'),
      ),
      body: tarefas.isEmpty
          ? const Center(child: Text('Nenhuma tarefa para este dia.'))
          : ListView.builder(
              itemCount: tarefas.length,
              itemBuilder: (context, index) {
                final item = tarefas[index];
                return ListTile(
                  leading: const Icon(Icons.access_time),
                  title: Text('${item['hora']} – ${item['tarefa']}'),
                );
              },
            ),
    );
  }
}
